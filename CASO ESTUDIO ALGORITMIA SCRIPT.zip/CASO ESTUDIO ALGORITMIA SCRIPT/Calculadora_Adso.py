
contador = 1
while contador != 0:
    continuar = 0
    print ("Bienvenido a la calculadora de ADSO\n")

    print("\nEn esta calculadora manejamos diferentes operaciones\n")

    print("\n1. Operaciones basicas\n")
    print("2. Operaciones Numericas\n")
    print("3. Conversiones de temperatura\n")
    print("4. IMC\n")
    print("5. Conversion de unidades de medida\n")
    print("6. Conversion de unidades de tiempo\n")
    print("0. Salir del programa\n")
    decision = int(input("\nPor favor digite el numero correspondiente a la operacion que desea realizar "))
    contador = decision

#operaciones basicas 
    if decision == 1 :
        while True :
            print("Bienvenido a la seccion de operaciones basicas\n")
            print("""               1. Suma 
                2. Resta 
                3. Multiplicacion  
                4. Division
                0. SALIR 
                """)
            basicas=int(input("Por favor digite el numero correspondiente a la operacion que desea realizar "))
            if basicas == 1:
                print("Bienvenido a la seccion de suma\n")
                suma=int(input("Por favor la cantidad de numeros que desea sumar: "))
                i = 1
                resultado = 0
                for i in range (suma):
                    num=int(input("Digite numero: "))
                    resultado += num 
                
                print(f"El resultado de su suma es de: {resultado} ")   
            elif basicas == 2 :
                resultado = 0
                print("""Bienvenido a la seccion de multiplicacion
                    
                    Recuerde que en esta seccion solo se podran restar dos numeros y podran ser decimales""")
                num1 = float(input("Digite el numero 1: "))
                num2 = float(input("Digite el numero 2: "))
                resultado = num1 - num2
                print(f"El resultado de su resta es de: {resultado} ")

            elif basicas == 3 :
                i = 1
                resultado = 1
                print("""Bienvenido a la seccion de multiplicar""")  

                suma=int(input("Por favor la cantidad de numeros que desea multiplicar: "))
                for i in range (suma):
                    num=int(input("Digite numero: "))
                    resultado *= num 
                
                print(f"El resultado de su multiplicacion es de: {resultado} ")  
            
            elif basicas == 4 :
                i = 1
                resultado = 0
                print("""Bienvenido a la seccion de division
                    
                    Recuerde que en esta seccion solo se podran dividir dos numeros y podran ser decimales""")  

                
                num1 = float(input("Digite el numero 1: "))
                num2 = float(input("Digite el numero 2: "))
                resultado = num1 / num2
                print(f"El resultado de su divison es de: {resultado} ")
                
                print(f"El resultado de su multiplicacion es de: {resultado} ")  
            
            else :
                print("GRACIAS POR USAR LA CALCULADORA BASICA")
                break
    
    if decision == 2:
        while True:
            print ("""Bienvenido a la seccion de operaciones numericas
                    
                    1. Convertir Decimales a Binarios
                    2. Convertir Binarios a Decimales
                    0. SALIR """)
            bina=int(input("\nIngrese el numero asignado a la operacion que desea realizar"))
            if bina == 1:
                num = int (input("Por favor ingrese el numero decimal a convertir: "))
                bin_num = bin(num)
                print(f"el binario del numero decimal es de : {bin_num}")

            elif bina == 2: 
                num = int(input("Por favor ingrese el numero binario a convertir: "))

                print ("El decimal del numero binario es de :",int(str(num),2))
            else :
                break
    
    if decision == 3:
        print("""Bienvenido a la seccion de conversion de temperatura""")
        while True:
            
      
            print("""\n \n Recuerde que en esta seccion solo se convierten grados Celsius a Farenheit""")
            cel=int(input("Por favor ingrese los grados Celsius a convertir"))
            faren = cel * 9/5 + 32 
            print(f"\nLa cantidad de grados Farenheit son:{faren}")
            continuar = int(input("Desea continuar 1. Si     2. No"))
            if continuar == 2:
                break
    if decision == 4:
        print("""Bienvenido a la seccion de imc 
              
              En esta calculadora usaremos enteros porque si :3
              """)
        while True:
            peso = int(input("Digite su Peso en KG: "))
            altura = float(input("Digite su altura en Cm y con . (1.63,1.70,1.89): "))
            imc = peso/altura**2
            print(imc)
            if imc > 1 and imc < 20:
                print("Bajo en peso")
            elif imc >= 20 and imc  < 25:
                print("Peso Normal")
            elif imc >= 25:
                print("Alto de peso")    

            continuar = int(input("Desea repetir 1. Si     2. No "))
            if continuar == 2:
                break
    if decision == 5 :
        while True :
            print("Bienvenido a la seccion de conversion de medidas \n")
            print("""                1. De centimetros a metros
                    2. De metros a centimetros
                    3. De metros de kilometros
                    4. De kilometros a metros  
                    0. SALIR                
                """)
            opMedida = int(input("Por favor digite el numero correspondiente a la operacion que desea realizar" ))
            if opMedida == 1 :
                numM1 = int(input("Digite los centimetros a convertir: "))
                metros = numM1/1000
                print(f"{numM1}cm a metros son : {metros}m")
            elif opMedida == 2 :
                numM1 = int(input("Digite los metros a convertir: "))
                metros = numM1*1000
                print(f"{numM1}m a centimetros son : {metros}cm")
            elif opMedida == 3 :
                numM1 = int(input("Digite los metros a convertir: "))
                metros = numM1/1000
                print(f"{numM1}m a kilometros son : {metros}km")
            elif opMedida == 4 :
                numM1 = int(input("Digite los kilometros  a convertir: "))
                metros = numM1*1000
                print(f"{numM1}km a metros son : {metros}" )
            else :
                break
    if decision == 6 :
        while True :
            print("Bienvenido a la seccion de conversion de tiempo  \n")
            print("""                     1. De segundos a minutos 
                        2. De minutos a segundos
                        3. De minutos a horas
                        4. De horas a minutos 
                        0. SALIR                           
                """)
            opMedida = int(input("Por favor digite el numero correspondiente a la operacion que desea realizar " ))
            if opMedida == 1 :
                numM1 = int(input("Digite los segundos a convertir: "))
                tiempo = numM1/60
                print(f"{numM1}s a minutos son: {tiempo}m " )
            elif opMedida == 2 :
                numM1 = int(input("Digite los minutos a convertir: "))
                tiempo = numM1*60
                print(f"{numM1}m a segundos son : {tiempo}" )
            elif opMedida == 3 :
                numM1 = int(input("Digite los minutos a convertir: "))
                tiempo = numM1/60
                print(f"{numM1}m a horas son : {tiempo}h " )
            elif opMedida == 4 :
                numM1 = int(input("Digite los horas  a convertir: "))
                tiempo = numM1*60
                print(f"{numM1}h a minutos son {tiempo}m" )
            else :
                break

            
            
            




            

    